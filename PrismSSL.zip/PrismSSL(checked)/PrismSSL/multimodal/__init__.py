from PrismSSL.multimodal.Trainer import Trainer

__all__ = ["Trainer"]
