from PrismSSL.multimodal.models.utils.registry import get_method, register_method

__all__ = [
    "get_method",
    "register_method",
]