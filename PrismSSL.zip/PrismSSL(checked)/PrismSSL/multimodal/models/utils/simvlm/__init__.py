from PrismSSL.multimodal.models.utils.simvlm.resblock import BottleneckBlock

__all__ = ["BottleneckBlock"]
