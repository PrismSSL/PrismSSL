# MK Unified SSL Toolbox - Webpage

A modern, professional webpage for the **MK Unified SSL Toolbox**, a modular Python library for self-supervised learning (SSL) across audio, vision, and multimodal tasks.

## 🎨 Design Features

- **Dark Theme**: Professional dark color scheme optimized for researchers and developers
- **Modern Layout**: Clean, minimal design with elegant typography
- **Responsive**: Fully responsive design that works on all devices
- **Interactive**: Smooth animations and hover effects
- **Accessible**: Built with accessibility in mind

## 📁 Project Structure

```
MK-SSL-Web-Page/
├── index.html          # Main HTML file
├── styles.css          # CSS styles with dark theme
├── script.js           # JavaScript for interactivity
└── README.md           # This file
```

## 🚀 Getting Started

1. **Clone or download** the project files
2. **Open `index.html`** in your web browser
3. **Enjoy** the modern, professional webpage!

No build process or dependencies required - it's pure HTML, CSS, and JavaScript.

## 🎯 Sections Included

### 1. **Hero Section**
- Eye-catching title with gradient text effect
- Animated floating cards representing different domains
- Call-to-action buttons for installation and GitHub

### 2. **About the Library**
- Comprehensive description of the SSL toolbox
- Statistics cards showing key metrics
- Professional presentation for researchers

### 3. **Supported Methods**
- **Vision**: SimCLR, MoCo, BYOL, SimSiam, SwAV, DINO, BarlowTwins, MAE
- **Audio**: Wav2Vec2, HuBERT, COLA, SimCLR for Speech
- **Multimodal**: CLAP, Wav2CLIP, Audio2CLIP

### 4. **Features**
- Modular components with icons
- Hugging Face integration
- Multi-GPU support
- LoRA fine-tuning
- Optuna integration
- Embedding animation
- WandB logging

### 5. **Trainer Utilities**
- Generic trainer modules
- Hugging Face compatibility
- Code examples with syntax highlighting

### 6. **Evaluation Tools**
- Linear probing and fine-tuning
- Visualization tools (t-SNE, UMAP)
- Embedding animation
- Standardized evaluation functions

### 7. **Installation**
- Multiple installation methods (pip, conda, apt)
- Source code links
- GitHub integration

### 8. **Roadmap**
- Distributed training plans
- CLI launcher tools
- Web-based monitoring
- Evaluation benchmarks

## 🎨 Design Elements

### Color Palette
- **Primary Background**: `#0a0a0a` (Deep Black)
- **Secondary Background**: `#111111` (Dark Gray)
- **Card Background**: `#1e1e1e` (Medium Gray)
- **Primary Accent**: `#6366f1` (Indigo)
- **Secondary Accent**: `#8b5cf6` (Purple)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Weights**: 300, 400, 500, 600, 700
- **Optimized** for readability on dark backgrounds

### Interactive Elements
- **Hover Effects**: Cards lift and glow on hover
- **Smooth Scrolling**: Navigation links scroll smoothly
- **Animations**: Fade-in effects and floating cards
- **Copy Buttons**: Code blocks have copy-to-clipboard functionality

## 📱 Responsive Design

The webpage is fully responsive and optimized for:
- **Desktop**: Full layout with all features
- **Tablet**: Adjusted grid layouts
- **Mobile**: Single-column layout with mobile menu

## 🔧 Customization

### Colors
Edit the CSS custom properties in `styles.css`:
```css
:root {
    --bg-primary: #0a0a0a;
    --accent-primary: #6366f1;
    /* ... other colors */
}
```

### Content
- Update the GitHub repository links in `index.html`
- Modify the installation commands
- Add or remove methods from the supported methods section

### Styling
- All styles are in `styles.css` with clear organization
- JavaScript interactions are in `script.js`
- Easy to modify animations and effects

## 🚀 Deployment

### GitHub Pages
1. Push to a GitHub repository
2. Enable GitHub Pages in repository settings
3. Select the main branch as source

### Netlify
1. Drag and drop the project folder to Netlify
2. Automatic deployment and HTTPS

### Vercel
1. Connect your GitHub repository
2. Automatic deployment on push

## 📄 License

This webpage is part of the MK Unified SSL Toolbox project. Please refer to the main project for licensing information.

## 🤝 Contributing

To contribute to the webpage:
1. Fork the repository
2. Make your changes
3. Test on different devices and browsers
4. Submit a pull request

## 📞 Support

For issues or questions about the webpage:
- Create an issue in the GitHub repository
- Contact the development team

---

**Built with ❤️ for the research community** 