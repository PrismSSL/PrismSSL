const STORAGE_KEY = 'prism-console-config-v2';

const state = {
    trainDatasetSummary: {},
    testDatasetSummary: {},
    valDatasetSummary: {},
    lastConfig: null,
    trainingStatus: 'idle',
    trainingPoller: null,
    evaluationStatus: 'idle',
    evaluationPoller: null,
};

function $(selector) {
    return document.querySelector(selector);
}

// Map of allowed self-supervised methods per modality
const METHOD_OPTIONS_BY_MODALITY = {
    audio: ['Wav2Vec2', 'HuBERT', 'SpeechSimCLR', 'COLA', 'EAT'],
    vision: ['MAE', 'BarlowTwins', 'BYOL', 'DINO', 'MoCov2', 'MoCov3', 'SimCLR', 'SimSiam', 'SwAV'],
    multimodal: ['CLAP', 'AudioCLIP', 'Wav2CLIP', 'CLIP', 'ALBEF', 'SimVLM', 'SLIP', 'UNITER', 'VSE'],
    graph: ['graphcl'],
};

function populateMethodOptions(modality, selected) {
    const methodSelect = $('#method');
    if (!methodSelect) return;
    methodSelect.innerHTML = '<option value="" disabled selected>Select</option>';
    const options = METHOD_OPTIONS_BY_MODALITY[modality] || [];
    options.forEach((name) => {
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        if (selected && selected === name) opt.selected = true;
        methodSelect.appendChild(opt);
    });
}

function showToast(title, message, type = 'info', duration = 5000) {
    const container = $('#toast-container');
    if (!container) return;
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    // Create icon based on type
    let iconSvg = '';
    switch (type) {
        case 'success':
            iconSvg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>';
            break;
        case 'error':
            iconSvg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>';
            break;
        case 'info':
        default:
            iconSvg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>';
            break;
    }
    
    // Create toast content
    toast.innerHTML = `
        <div class="toast-icon">${iconSvg}</div>
        <div class="toast-content">
            <h4 class="toast-title">${title}</h4>
            <p class="toast-message">${message}</p>
        </div>
        <button class="toast-close" aria-label="Close notification">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
        </button>
        <div class="toast-progress"></div>
    `;
    
    // Add close functionality
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
        removeToast(toast);
    });
    
    // Add to container
    container.appendChild(toast);
    
    // Trigger animation
    requestAnimationFrame(() => {
        toast.classList.add('show');
    });
    
    // Auto-remove after duration
    if (duration > 0) {
        const progressBar = toast.querySelector('.toast-progress');
        progressBar.style.width = '100%';
        progressBar.style.transitionDuration = `${duration}ms`;
        
        setTimeout(() => {
            removeToast(toast);
        }, duration);
    }
    
    return toast;
}

function removeToast(toast) {
    if (!toast || !toast.parentNode) return;
    
    toast.classList.remove('show');
    toast.style.transform = 'translateX(100%)';
    toast.style.opacity = '0';
    
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 300);
}

function showMessage(message, type = 'neutral') {
    const area = $('#message-area');
    if (!area) return;
    
    // Clear previous content and classes
    area.innerHTML = '';
    area.className = '';
    
    if (!message) return;
    
    // Create message container with enhanced styling
    const messageContainer = document.createElement('div');
    messageContainer.style.cssText = `
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 1rem 1.25rem;
        border-radius: 0.5rem;
        font-weight: 600;
        font-size: 0.95rem;
        line-height: 1.4;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        border: 2px solid;
        animation: slideInFromTop 0.3s ease-out;
        max-width: 100%;
        word-wrap: break-word;
    `;
    
    // Add animation keyframes if not already added
    if (!document.getElementById('message-animations')) {
        const style = document.createElement('style');
        style.id = 'message-animations';
        style.textContent = `
            @keyframes slideInFromTop {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            @keyframes fadeOut {
                from {
                    opacity: 1;
                    transform: translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateY(-10px);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Create icon based on message type
    const icon = document.createElement('div');
    icon.style.cssText = `
        flex-shrink: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    // Create message text
    const messageText = document.createElement('span');
    messageText.textContent = message;
    messageText.style.cssText = `
        flex: 1;
        font-weight: 600;
    `;
    
    // Style based on message type
    if (type === 'success') {
        messageContainer.style.cssText += `
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            border-color: #047857;
        `;
        icon.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
            </svg>
        `;
    } else if (type === 'error') {
        messageContainer.style.cssText += `
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            border-color: #b91c1c;
        `;
        icon.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
        `;
    } else {
        // Neutral/info style
        messageContainer.style.cssText += `
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border-color: #1d4ed8;
        `;
        icon.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
            </svg>
        `;
    }
    
    // Add close button
    const closeButton = document.createElement('button');
    closeButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
        </svg>
    `;
    closeButton.style.cssText = `
        background: none;
        border: none;
        color: inherit;
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 0.25rem;
        opacity: 0.8;
        transition: opacity 0.2s;
        flex-shrink: 0;
    `;
    closeButton.addEventListener('mouseenter', () => {
        closeButton.style.opacity = '1';
    });
    closeButton.addEventListener('mouseleave', () => {
        closeButton.style.opacity = '0.8';
    });
    closeButton.addEventListener('click', () => {
        messageContainer.style.animation = 'fadeOut 0.2s ease-out';
        setTimeout(() => {
            area.innerHTML = '';
        }, 200);
    });
    
    // Assemble the message
    messageContainer.appendChild(icon);
    messageContainer.appendChild(messageText);
    messageContainer.appendChild(closeButton);
    area.appendChild(messageContainer);
    
    // Auto-hide after 5 seconds for non-error messages
    if (type !== 'error') {
        setTimeout(() => {
            if (area.contains(messageContainer)) {
                messageContainer.style.animation = 'fadeOut 0.2s ease-out';
                setTimeout(() => {
                    if (area.contains(messageContainer)) {
                        area.innerHTML = '';
                    }
                }, 200);
            }
        }, 5000);
    }
}

function stopTrainingPoller() {
    if (state.trainingPoller) {
        clearInterval(state.trainingPoller);
        state.trainingPoller = null;
    }
}

function startTrainingPoller() {
    if (state.trainingPoller) return;
    state.trainingPoller = setInterval(() => {
        checkTrainingStatus({ notifyOnComplete: true });
    }, 4000);
}

function stopEvaluationPoller() {
    if (state.evaluationPoller) {
        clearInterval(state.evaluationPoller);
        state.evaluationPoller = null;
    }
}

function startEvaluationPoller() {
    if (state.evaluationPoller) return;
    state.evaluationPoller = setInterval(() => {
        checkEvaluationStatus({ notifyOnComplete: true });
    }, 4000);
}

function applyTrainingStatus(running, options = {}) {
    const previous = state.trainingStatus;
    state.trainingStatus = running ? 'running' : 'idle';
    const button = $('#start-pretext-training');
    if (button) {
        const idleLabel = button.dataset.labelIdle || 'Start pretext training';
        const runningLabel = button.dataset.labelRunning || 'Training…';
        if (running) {
            button.disabled = true;
            button.textContent = runningLabel;
        } else {
            button.disabled = false;
            button.textContent = idleLabel;
        }
    }
    if (running) {
        startTrainingPoller();
    } else {
        stopTrainingPoller();
        if (options.notifyOnComplete && previous === 'running') {
            showMessage('Pretext training finished.', 'success');
        }
    }
}

function applyEvaluationStatus(running, options = {}) {
    const previous = state.evaluationStatus;
    state.evaluationStatus = running ? 'running' : 'idle';
    const button = $('#start-evaluation');
    if (button) {
        const idleLabel = button.dataset.labelIdle || 'Start evaluation';
        const runningLabel = button.dataset.labelRunning || 'Evaluating…';
        if (running) {
            button.disabled = true;
            button.textContent = runningLabel;
        } else {
            button.disabled = false;
            button.textContent = idleLabel;
        }
    }
    if (running) {
        startEvaluationPoller();
    } else {
        stopEvaluationPoller();
        if (options.notifyOnComplete && previous === 'running') {
            showMessage('Evaluation finished.', 'success');
        }
    }
}

function checkTrainingStatus(options = {}) {
    return fetch('/api/train/status')
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || 'Unable to determine training status.');
            applyTrainingStatus(Boolean(data.running), {
                notifyOnComplete: Boolean(options.notifyOnComplete),
            });
        })
        .catch((error) => {
            console.warn('Unable to fetch training status', error);
        });
}

function checkEvaluationStatus(options = {}) {
    return fetch('/api/evaluate/status')
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || 'Unable to determine evaluation status.');
            applyEvaluationStatus(Boolean(data.running), {
                notifyOnComplete: Boolean(options.notifyOnComplete),
            });
        })
        .catch((error) => {
            console.warn('Unable to fetch evaluation status', error);
        });
}

function getStoredTheme() {
    return localStorage.getItem('prism-theme') || 'light';
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('prism-theme', theme);
    const icon = $('#theme-icon');
    if (icon) {
        if (theme === 'dark') {
            // Moon icon for dark mode
            icon.innerHTML = '<path d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z"/>';
        } else {
            // Sun icon for light mode
            icon.innerHTML = '<path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z"/>';
        }
    }
}

function toggleTheme() {
    const current = getStoredTheme();
    applyTheme(current === 'light' ? 'dark' : 'light');
}

function parseJson(text, fallback = null) {
    if (!text || !text.trim()) return fallback;
    try {
        return JSON.parse(text);
    } catch (error) {
        throw new Error(error.message || 'Invalid JSON');
    }
}

function detectDatasetClasses(type) {
    const codeField = `#${type}-dataset-code`;
    const selectField = `#${type}-dataset-class`;
    const code = $(codeField).value;
    
    if (!code.trim()) {
        showToast(
            'No Code Found',
            `Please paste your ${type} dataset code before running detection.`,
            'error',
            4000
        );
        return;
    }
    
    // Show loading toast
    const loadingToast = showToast(
        'Analyzing Code',
        `Scanning ${type} dataset code for class definitions...`,
        'info',
        0 // Don't auto-remove
    );
    
    fetch('/api/dataset/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
    })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            // Remove loading toast
            if (loadingToast) {
                removeToast(loadingToast);
            }
            
            if (!ok) throw new Error(data.error || 'Unable to inspect dataset.');
            
            const classes = data.classes || [];
            const select = $(selectField);
            select.innerHTML = '<option value="" disabled selected>Select a class</option>';
            
            if (classes.length === 0) {
                showToast(
                    'No Classes Detected',
                    `No valid class definitions found in ${type} dataset code. Please check your code contains proper class definitions.`,
                    'error',
                    6000
                );
                return;
            }
            
            classes.forEach((cls) => {
                const option = document.createElement('option');
                option.value = cls;
                option.textContent = cls;
                select.appendChild(option);
            });
            
            // Success toast with class details
            const classList = classes.length <= 3 
                ? classes.join(', ') 
                : `${classes.slice(0, 3).join(', ')} and ${classes.length - 3} more`;
            
            const message = classes.length === 1 
                ? `Found class: ${classes[0]}`
                : `Found ${classes.length} classes: ${classList}`;
            
            showToast(
                'Classes Detected Successfully',
                message,
                'success',
                5000
            );
        })
        .catch((error) => {
            // Remove loading toast
            if (loadingToast) {
                removeToast(loadingToast);
            }
            
            showToast(
                'Detection Failed',
                `Failed to analyze ${type} dataset code: ${error.message}`,
                'error',
                6000
            );
        });
}

function renderDatasetSummary(summary, type) {
    const container = $(`#${type}-dataset-summary`);
    container.innerHTML = '';
    const entries = Object.entries(summary || {});
    if (!entries.length) {
        const empty = document.createElement('p');
        empty.textContent = `No ${type} dataset preview available yet.`;
        container.appendChild(empty);
        return;
    }
    entries.forEach(([split, info]) => {
        const card = document.createElement('div');
        card.className = 'summary-card';
        const details = [];
        if (info.length !== undefined && info.length !== null) {
            details.push(`Length: ${info.length}`);
        }
        if (info.preview) {
            details.push(`Preview: ${info.preview}`);
        }
        card.innerHTML = `<strong>${split}</strong><br>${details.join('<br>') || 'No additional information'}`;
        container.appendChild(card);
    });
}

function instantiateDatasets(type) {
    const codeField = `#${type}-dataset-code`;
    const classField = `#${type}-dataset-class`;
    const kwargsField = `#${type}-dataset-kwargs`;
    const code = $(codeField).value;
    const className = $(classField).value;
    if (!code.trim() || !className) {
        showMessage(`Provide ${type} dataset code and select a class before previewing.`, 'error');
        return;
    }
    let kwargs;
    try {
        kwargs = parseJson($(kwargsField).value, {});
    } catch (error) {
        showMessage(`${type} dataset argument error: ${error.message}`, 'error');
        return;
    }
    const payload = {
        code,
        class_name: className,
        kwargs_train: kwargs,
    };
    fetch('/api/dataset/instantiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || 'Dataset instantiation failed');
            state[`${type}DatasetSummary`] = data.summary || {};
            renderDatasetSummary(state[`${type}DatasetSummary`], type);
            persistConfig({ 
                [`${type}_dataset`]: { code, class_name: className, kwargs }, 
                [`${type}_dataset_summary`]: state[`${type}DatasetSummary`] 
            });
            showMessage(`${type} dataset summary prepared.`, 'success');
        })
        .catch((error) => {
            showMessage(error.message, 'error');
        });
}

function sanitize(value) {
    if (value === undefined || value === null) return null;
    const trimmed = String(value).trim();
    return trimmed === '' ? null : trimmed;
}

function collectTrainerConfig() {
    const modality = sanitize($('#modality').value);
    const method = sanitize($('#method').value);
    if (!modality || !method) {
        throw new Error('Modality and method are required.');
    }
    const trainerCtor = {
        method,
        variant: sanitize($('#variant').value) || 'base',
        save_dir: sanitize($('#save_dir').value) || './checkpoints',
        checkpoint_interval: Number($('#checkpoint_interval').value) || 1,
        reload_checkpoint: $('#reload_checkpoint').checked,
        verbose: $('#verbose').checked,
        mixed_precision_training: $('#mixed_precision_training').checked,
        use_data_parallel: $('#use_data_parallel').checked,
    };
    const workers = $('#num_workers').value;
    if (workers) {
        trainerCtor.num_workers = Number(workers);
    }
    const wandbProject = sanitize($('#wandb_project').value);
    const wandbEntity = sanitize($('#wandb_entity').value);
    const wandbRunName = sanitize($('#wandb_run_name').value);
    const wandbNotes = sanitize($('#wandb_notes').value);
    const wandbTags = sanitize($('#wandb_tags').value);
    trainerCtor.wandb_mode = $('#wandb_mode').value || 'online';
    if (wandbProject) trainerCtor.wandb_project = wandbProject;
    if (wandbEntity) trainerCtor.wandb_entity = wandbEntity;
    if (wandbRunName) trainerCtor.wandb_run_name = wandbRunName;
    if (wandbNotes) trainerCtor.wandb_notes = wandbNotes;
    if (wandbTags) {
        trainerCtor.wandb_tags = wandbTags.split(',').map((tag) => tag.trim()).filter(Boolean);
    }
    const wandbConfig = $('#wandb_config').value;
    if (wandbConfig.trim()) {
        trainerCtor.wandb_config = parseJson(wandbConfig, {});
    }
    // GenericSSL is disabled for future versions
    const useGeneric = false;
    return {
        modality,
        trainer_ctor: trainerCtor,
        use_generic: useGeneric,
        generic: {},
    };
}

function collectTrainArgs() {
    const epochs = Number($('#epochs').value);
    const batchSize = Number($('#batch_size').value);
    const learningRate = Number($('#learning_rate').value);
    if (Number.isNaN(epochs) || epochs < 1) throw new Error('Epochs must be at least 1.');
    if (Number.isNaN(batchSize) || batchSize < 1) throw new Error('Batch size must be at least 1.');
    if (Number.isNaN(learningRate) || learningRate <= 0) throw new Error('Learning rate must be greater than 0.');
    const args = {
        batch_size: batchSize,
        epochs,
        start_epoch: Number($('#start_epoch').value) || 0,
        start_iteration: Number($('#start_iteration').value) || 0,
        learning_rate: learningRate,
        weight_decay: Number($('#weight_decay').value) || 0,
        optimizer: $('#optimizer').value || 'adamw',
        use_hpo: $('#use_hpo').checked,
        n_trials: Number($('#n_trials').value) || 20,
        tuning_epochs: Number($('#tuning_epochs').value) || 5,
        use_embedding_logger: $('#use_embedding_logger').checked,
    };
    if (args.use_hpo) {
        if (args.n_trials < 1) throw new Error('Number of HPO trials must be at least 1.');
        if (args.tuning_epochs < 1) throw new Error('Tuning epochs must be at least 1.');
    }
    const extra = $('#train_kwargs').value;
    if (extra.trim()) {
        args.extra_kwargs = parseJson(extra, {});
    }
    return args;
}

function collectEvalArgs() {
    if (!$('#include-eval').checked) {
        return null;
    }
    const args = {
        num_classes: Number($('#eval_num_classes').value) || 0,
        batch_size: Number($('#eval_batch_size').value) || 0,
        lr: Number($('#eval_lr').value) || 0,
        epochs: Number($('#eval_epochs').value) || 0,
        freeze_backbone: $('#eval_freeze_backbone').checked,
    };
    const extra = $('#eval_kwargs').value;
    if (extra.trim()) {
        args.extra_kwargs = parseJson(extra, {});
    }
    return args;
}

function collectDatasetConfig() {
    const datasets = {};
    
    // Collect training dataset
    const trainCode = $('#train-dataset-code').value.trim();
    const trainClass = $('#train-dataset-class').value;
    if (trainCode && trainClass) {
        try {
            datasets.train = {
                code: trainCode,
                class_name: trainClass,
                kwargs: parseJson($('#train-dataset-kwargs').value, {}),
            };
        } catch (error) {
            throw new Error(`Training dataset argument error: ${error.message}`);
        }
    }
    
    // Collect test dataset
    const testCode = $('#test-dataset-code').value.trim();
    const testClass = $('#test-dataset-class').value;
    if (testCode && testClass) {
        try {
            datasets.test = {
                code: testCode,
                class_name: testClass,
                kwargs: parseJson($('#test-dataset-kwargs').value, {}),
            };
        } catch (error) {
            throw new Error(`Test dataset argument error: ${error.message}`);
        }
    }
    
    // Collect validation dataset
    const valCode = $('#val-dataset-code').value.trim();
    const valClass = $('#val-dataset-class').value;
    if (valCode && valClass) {
        try {
            datasets.val = {
                code: valCode,
                class_name: valClass,
                kwargs: parseJson($('#val-dataset-kwargs').value, {}),
            };
        } catch (error) {
            throw new Error(`Validation dataset argument error: ${error.message}`);
        }
    }
    
    if (Object.keys(datasets).length === 0) {
        throw new Error('At least one dataset (train, test, or validation) is required.');
    }
    
    return datasets;
}

function gatherFullConfig() {
    const trainer = collectTrainerConfig();
    const train = collectTrainArgs();
    const dataset = collectDatasetConfig();
    const evalArgs = collectEvalArgs();
    const config = { trainer, train, dataset };
    if (evalArgs) {
        config.eval = evalArgs;
    }
    return config;
}

function persistConfig(partial) {
    const updated = { ...(state.lastConfig || {}), ...partial };
    state.lastConfig = updated;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

function restoreConfig() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    try {
        const config = JSON.parse(stored);
        state.lastConfig = config;
        
        // Restore training dataset
        if (config.train_dataset) {
            $('#train-dataset-code').value = config.train_dataset.code || '';
            const trainSelect = $('#train-dataset-class');
            trainSelect.innerHTML = '<option value="" disabled>Select a class</option>';
            if (config.train_dataset.class_name) {
                const option = document.createElement('option');
                option.value = config.train_dataset.class_name;
                option.textContent = config.train_dataset.class_name;
                option.selected = true;
                trainSelect.appendChild(option);
            }
            $('#train-dataset-kwargs').value = config.train_dataset.kwargs
                ? JSON.stringify(config.train_dataset.kwargs, null, 2)
                : '';
        }
        state.trainDatasetSummary = config.train_dataset_summary || {};
        
        // Restore test dataset
        if (config.test_dataset) {
            $('#test-dataset-code').value = config.test_dataset.code || '';
            const testSelect = $('#test-dataset-class');
            testSelect.innerHTML = '<option value="" disabled>Select a class</option>';
            if (config.test_dataset.class_name) {
                const option = document.createElement('option');
                option.value = config.test_dataset.class_name;
                option.textContent = config.test_dataset.class_name;
                option.selected = true;
                testSelect.appendChild(option);
            }
            $('#test-dataset-kwargs').value = config.test_dataset.kwargs
                ? JSON.stringify(config.test_dataset.kwargs, null, 2)
                : '';
        }
        state.testDatasetSummary = config.test_dataset_summary || {};
        
        // Restore validation dataset
        if (config.val_dataset) {
            $('#val-dataset-code').value = config.val_dataset.code || '';
            const valSelect = $('#val-dataset-class');
            valSelect.innerHTML = '<option value="" disabled>Select a class</option>';
            if (config.val_dataset.class_name) {
                const option = document.createElement('option');
                option.value = config.val_dataset.class_name;
                option.textContent = config.val_dataset.class_name;
                option.selected = true;
                valSelect.appendChild(option);
            }
            $('#val-dataset-kwargs').value = config.val_dataset.kwargs
                ? JSON.stringify(config.val_dataset.kwargs, null, 2)
                : '';
        }
        state.valDatasetSummary = config.val_dataset_summary || {};
        if (config.trainer) {
            $('#modality').value = config.trainer.modality || '';
            const ctor = config.trainer.trainer_ctor || {};
            // Populate method options based on modality and select saved method
            if (config.trainer.modality) {
                populateMethodOptions(config.trainer.modality, ctor.method || '');
            }
            $('#variant').value = ctor.variant || 'base';
            $('#save_dir').value = ctor.save_dir || './checkpoints';
            $('#checkpoint_interval').value = ctor.checkpoint_interval ?? 1;
            $('#num_workers').value = ctor.num_workers ?? '';
            $('#reload_checkpoint').checked = !!ctor.reload_checkpoint;
            $('#verbose').checked = ctor.verbose !== false;
            $('#mixed_precision_training').checked = ctor.mixed_precision_training !== false;
            $('#use_data_parallel').checked = !!ctor.use_data_parallel;
            $('#wandb_project').value = ctor.wandb_project || '';
            $('#wandb_entity').value = ctor.wandb_entity || '';
            $('#wandb_run_name').value = ctor.wandb_run_name || '';
            $('#wandb_mode').value = ctor.wandb_mode || 'online';
            $('#wandb_notes').value = ctor.wandb_notes || '';
            $('#wandb_tags').value = (ctor.wandb_tags || []).join(', ');
            $('#wandb_config').value = ctor.wandb_config ? JSON.stringify(ctor.wandb_config, null, 2) : '';
        }
        // GenericSSL is disabled for future versions
        $('#use_generic').checked = false;
        $('#generic-settings').hidden = true;
        if (config.train) {
            $('#batch_size').value = config.train.batch_size || 16;
            $('#epochs').value = config.train.epochs || 1;
            $('#learning_rate').value = config.train.learning_rate || 0.0001;
            $('#weight_decay').value = config.train.weight_decay ?? 0.01;
            $('#optimizer').value = config.train.optimizer || 'adamw';
            $('#start_epoch').value = config.train.start_epoch || 0;
            $('#start_iteration').value = config.train.start_iteration || 0;
            $('#use_hpo').checked = !!config.train.use_hpo;
            $('#use_embedding_logger').checked = !!config.train.use_embedding_logger;
            $('#n_trials').value = config.train.n_trials || 20;
            $('#tuning_epochs').value = config.train.tuning_epochs || 5;
            $('#train_kwargs').value = config.train.extra_kwargs
                ? JSON.stringify(config.train.extra_kwargs, null, 2)
                : '';
        }
        if (config.eval) {
            $('#include-eval').checked = true;
            $('#eval_num_classes').value = config.eval.num_classes || 1;
            $('#eval_batch_size').value = config.eval.batch_size || 64;
            $('#eval_lr').value = config.eval.lr || 0.001;
            $('#eval_epochs').value = config.eval.epochs || 1;
            $('#eval_freeze_backbone').checked = config.eval.freeze_backbone !== false;
            $('#eval_kwargs').value = config.eval.extra_kwargs ? JSON.stringify(config.eval.extra_kwargs, null, 2) : '';
        } else {
            $('#include-eval').checked = false;
            $('#evaluation-fields').style.display = 'none';
        }
    } catch (error) {
        console.warn('Failed to restore configuration', error);
    }
}

function exportConfig() {
    try {
        const config = gatherFullConfig();
        const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'prismssl-config.json';
        link.click();
        URL.revokeObjectURL(link.href);
        showMessage('Configuration exported.', 'success');
    } catch (error) {
        showMessage(error.message, 'error');
    }
}

function importConfig(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        try {
            const config = JSON.parse(reader.result);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
            restoreConfig();
            showMessage('Configuration imported.', 'success');
        } catch (error) {
            showMessage('Unable to import configuration.', 'error');
        }
    };
    reader.readAsText(file);
}

function updateEvaluationVisibility() {
    const container = $('#evaluation-fields');
    if ($('#include-eval').checked) {
        container.style.display = '';
    } else {
        container.style.display = 'none';
    }
}

function updateGenericVisibility() {
    // GenericSSL is disabled for future versions
    $('#generic-settings').hidden = true;
}

function renderConfigTable(config) {
    const preview = $('#config-preview');
    preview.innerHTML = '';
    
    // Add table styles if not already added
    if (!document.getElementById('config-table-styles')) {
        const style = document.createElement('style');
        style.id = 'config-table-styles';
        style.textContent = `
            .config-table {
                width: 100%;
                border-collapse: collapse;
                background: var(--surface);
                border-radius: 0.5rem;
                overflow: hidden;
                box-shadow: var(--shadow);
                font-size: 0.9rem;
                border: 1px solid var(--border);
            }
            .config-table th {
                background: var(--accent);
                color: var(--bg);
                padding: 1rem;
                text-align: left;
                font-weight: 600;
                font-size: 0.95rem;
            }
            .config-table td {
                padding: 0.75rem 1rem;
                border-bottom: 1px solid var(--border);
                vertical-align: top;
                color: var(--text);
            }
            .config-table tr:last-child td {
                border-bottom: none;
            }
            .config-table tr:hover {
                background-color: var(--surface-muted);
            }
            .config-section {
                font-weight: 600;
                color: var(--text);
                background-color: var(--surface-muted);
                padding: 0.5rem 0.75rem;
                border-radius: 0.25rem;
                margin-bottom: 0.5rem;
                display: inline-block;
                border: 1px solid var(--border);
            }
            .config-value {
                font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                background-color: var(--surface-muted);
                color: var(--text);
                padding: 0.25rem 0.5rem;
                border-radius: 0.25rem;
                border: 1px solid var(--border);
                word-break: break-all;
            }
            .config-json {
                background-color: var(--surface-muted);
                color: var(--text);
                padding: 1rem;
                border-radius: 0.5rem;
                font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                font-size: 0.85rem;
                line-height: 1.5;
                overflow-x: auto;
                white-space: pre-wrap;
                margin-top: 1rem;
                border: 1px solid var(--border);
            }
            .config-toggle {
                background: var(--accent);
                color: var(--bg);
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 0.25rem;
                cursor: pointer;
                font-weight: 600;
                margin-bottom: 1rem;
                transition: all 0.2s;
            }
            .config-toggle:hover {
                transform: translateY(-1px);
                box-shadow: var(--shadow);
            }
        `;
        document.head.appendChild(style);
    }
    
    // Create toggle button for JSON view
    const toggleButton = document.createElement('button');
    toggleButton.className = 'config-toggle';
    toggleButton.textContent = 'Show Raw JSON';
    let showJson = false;
    
    toggleButton.addEventListener('click', () => {
        showJson = !showJson;
        toggleButton.textContent = showJson ? 'Show Table View' : 'Show Raw JSON';
        if (showJson) {
            preview.innerHTML = '';
            const jsonDiv = document.createElement('div');
            jsonDiv.className = 'config-json';
            jsonDiv.textContent = JSON.stringify(config, null, 2);
            preview.appendChild(toggleButton);
            preview.appendChild(jsonDiv);
        } else {
            renderConfigTable(config);
        }
    });
    
    preview.appendChild(toggleButton);
    
    // Create table
    const table = document.createElement('table');
    table.className = 'config-table';
    
    // Helper function to create table rows
    function createRow(label, value, isSection = false) {
        const row = document.createElement('tr');
        const labelCell = document.createElement('td');
        const valueCell = document.createElement('td');
        
        if (isSection) {
            labelCell.innerHTML = `<div class="config-section">${label}</div>`;
            valueCell.innerHTML = '';
        } else {
            labelCell.textContent = label;
            if (typeof value === 'object' && value !== null) {
                valueCell.innerHTML = `<div class="config-value">${JSON.stringify(value, null, 2)}</div>`;
            } else {
                valueCell.innerHTML = `<div class="config-value">${value}</div>`;
            }
        }
        
        row.appendChild(labelCell);
        row.appendChild(valueCell);
        return row;
    }
    
    // Add trainer configuration
    if (config.trainer) {
        table.appendChild(createRow('Trainer Configuration', '', true));
        table.appendChild(createRow('Modality', config.trainer.modality || 'Not specified'));
        
        if (config.trainer.trainer_ctor) {
            const ctor = config.trainer.trainer_ctor;
            table.appendChild(createRow('Method', ctor.method || 'Not specified'));
            table.appendChild(createRow('Variant', ctor.variant || 'base'));
            table.appendChild(createRow('Save Directory', ctor.save_dir || './checkpoints'));
            table.appendChild(createRow('Checkpoint Interval', ctor.checkpoint_interval || 1));
            table.appendChild(createRow('Reload Checkpoint', ctor.reload_checkpoint ? 'Yes' : 'No'));
            table.appendChild(createRow('Verbose Logging', ctor.verbose ? 'Yes' : 'No'));
            table.appendChild(createRow('Mixed Precision', ctor.mixed_precision_training ? 'Yes' : 'No'));
            table.appendChild(createRow('Data Parallel', ctor.use_data_parallel ? 'Yes' : 'No'));
            
            if (ctor.num_workers) {
                table.appendChild(createRow('Data Loader Workers', ctor.num_workers));
            }
            
            // WandB configuration
            if (ctor.wandb_project || ctor.wandb_entity || ctor.wandb_run_name) {
                table.appendChild(createRow('WandB Project', ctor.wandb_project || 'Not specified'));
                table.appendChild(createRow('WandB Entity', ctor.wandb_entity || 'Not specified'));
                table.appendChild(createRow('WandB Run Name', ctor.wandb_run_name || 'Not specified'));
                table.appendChild(createRow('WandB Mode', ctor.wandb_mode || 'online'));
            }
        }
        
        if (config.trainer.use_generic && config.trainer.generic) {
            table.appendChild(createRow('Generic Model Name', config.trainer.generic.model_name || 'Not specified'));
            table.appendChild(createRow('Generic Epochs', config.trainer.generic.epochs || 1));
            table.appendChild(createRow('Use LoRA', config.trainer.generic.use_lora ? 'Yes' : 'No'));
        }
    }
    
    // Add training configuration
    if (config.train) {
        table.appendChild(createRow('Training Configuration', '', true));
        table.appendChild(createRow('Batch Size', config.train.batch_size || 'Not specified'));
        table.appendChild(createRow('Epochs', config.train.epochs || 'Not specified'));
        table.appendChild(createRow('Learning Rate', config.train.learning_rate || 'Not specified'));
        table.appendChild(createRow('Weight Decay', config.train.weight_decay || 'Not specified'));
        table.appendChild(createRow('Optimizer', config.train.optimizer || 'adamw'));
        table.appendChild(createRow('Start Epoch', config.train.start_epoch || 0));
        table.appendChild(createRow('Start Iteration', config.train.start_iteration || 0));
        table.appendChild(createRow('Hyperparameter Search', config.train.use_hpo ? 'Yes' : 'No'));
        
        if (config.train.use_hpo) {
            table.appendChild(createRow('HPO Trials', config.train.n_trials || 20));
            table.appendChild(createRow('Tuning Epochs', config.train.tuning_epochs || 5));
        }
        
        table.appendChild(createRow('Embedding Logger', config.train.use_embedding_logger ? 'Yes' : 'No'));
        
        if (config.train.extra_kwargs) {
            table.appendChild(createRow('Extra Training Args', config.train.extra_kwargs));
        }
    }
    
    // Add evaluation configuration
    if (config.eval) {
        table.appendChild(createRow('Evaluation Configuration', '', true));
        table.appendChild(createRow('Number of Classes', config.eval.num_classes || 'Not specified'));
        table.appendChild(createRow('Batch Size', config.eval.batch_size || 'Not specified'));
        table.appendChild(createRow('Learning Rate', config.eval.lr || 'Not specified'));
        table.appendChild(createRow('Epochs', config.eval.epochs || 'Not specified'));
        table.appendChild(createRow('Freeze Backbone', config.eval.freeze_backbone ? 'Yes' : 'No'));
        
        if (config.eval.extra_kwargs) {
            table.appendChild(createRow('Extra Evaluation Args', config.eval.extra_kwargs));
        }
    }
    
    // Add dataset configuration
    if (config.dataset) {
        table.appendChild(createRow('Dataset Configuration', '', true));
        
        Object.entries(config.dataset).forEach(([type, dataset]) => {
            table.appendChild(createRow(`${type.charAt(0).toUpperCase() + type.slice(1)} Dataset`, '', true));
            table.appendChild(createRow('Class Name', dataset.class_name || 'Not specified'));
            table.appendChild(createRow('Arguments', dataset.kwargs || {}));
        });
    }
    
    preview.appendChild(table);
}

function generateRunSheet() {
    showMessage('');
    try {
        const config = gatherFullConfig();
        persistConfig(config);
        fetch('/api/config/preview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                trainer: config.trainer,
                train_args: config.train,
                eval_args: config.eval || null,
                dataset: config.dataset,
            }),
        })
            .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
            .then(({ ok, data }) => {
                if (!ok) throw new Error(Object.values(data.errors || {}).join('\n') || 'Validation failed.');
                renderConfigTable(data.config);
                showMessage('Configuration validated. You can now run training from the terminal.', 'success');
            })
            .catch((error) => {
                showMessage(error.message, 'error');
            });
    } catch (error) {
        showMessage(error.message, 'error');
    }
}

function startPretextTraining() {
    showMessage('');
    let config;
    try {
        config = gatherFullConfig();
        persistConfig(config);
    } catch (error) {
        showMessage(error.message, 'error');
        return;
    }
    const button = $('#start-pretext-training');
    if (button) {
        button.disabled = true;
    }
    fetch('/api/train/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config }),
    })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) {
                const message =
                    Object.values(data.errors || {}).join('\n') ||
                    data.error ||
                    'Unable to start training.';
                throw new Error(message);
            }
            applyTrainingStatus(true);
            showMessage('Pretext training started in the background.', 'success');
        })
        .catch((error) => {
            applyTrainingStatus(false, { notifyOnComplete: false });
            showMessage(error.message, 'error');
        });
}

function startEvaluation() {
    showMessage('');
    let config;
    try {
        config = gatherFullConfig();
        persistConfig(config);
    } catch (error) {
        showMessage(error.message, 'error');
        return;
    }
    
    // Check if evaluation configuration is included
    if (!$('#include-eval').checked) {
        showMessage('Please enable evaluation parameters before starting evaluation.', 'error');
        return;
    }
    
    const button = $('#start-evaluation');
    if (button) {
        button.disabled = true;
    }
    fetch('/api/evaluate/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config }),
    })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) {
                const message = data.error || 'Unable to start evaluation.';
                throw new Error(message);
            }
            applyEvaluationStatus(true);
            showMessage('Evaluation started in the background.', 'success');
        })
        .catch((error) => {
            applyEvaluationStatus(false, { notifyOnComplete: false });
            showMessage(error.message, 'error');
        });
}

function clearDataset(type) {
    $(`#${type}-dataset-code`).value = '';
    $(`#${type}-dataset-class`).innerHTML = '<option value="" disabled selected>Select a class</option>';
    $(`#${type}-dataset-summary`).innerHTML = '';
    state[`${type}DatasetSummary`] = {};
}


function bindEvents() {
    // Update method options when modality changes
    $('#modality').addEventListener('change', (e) => {
        const modality = e.target.value;
        populateMethodOptions(modality, '');
    });
    $('#theme-toggle').addEventListener('click', toggleTheme);
    
    // Training dataset events
    $('#detect-train-dataset').addEventListener('click', () => detectDatasetClasses('train'));
    $('#clear-train-dataset').addEventListener('click', () => clearDataset('train'));
    $('#instantiate-train-dataset').addEventListener('click', () => instantiateDatasets('train'));
    
    // Test dataset events (disabled for future versions)
    // $('#detect-test-dataset').addEventListener('click', () => detectDatasetClasses('test'));
    // $('#clear-test-dataset').addEventListener('click', () => clearDataset('test'));
    // $('#instantiate-test-dataset').addEventListener('click', () => instantiateDatasets('test'));
    
    // Validation dataset events
    $('#detect-val-dataset').addEventListener('click', () => detectDatasetClasses('val'));
    $('#clear-val-dataset').addEventListener('click', () => clearDataset('val'));
    $('#instantiate-val-dataset').addEventListener('click', () => instantiateDatasets('val'));
    
    $('#export-config').addEventListener('click', exportConfig);
    $('#import-config').addEventListener('change', importConfig);
    $('#generate-run-sheet').addEventListener('click', generateRunSheet);
    $('#start-pretext-training').addEventListener('click', startPretextTraining);
    $('#start-evaluation').addEventListener('click', (e) => {
        e.preventDefault();
        showMessage('Evaluation feature is coming in future versions.', 'error');
    });
    // GenericSSL is disabled for future versions - no event listener needed
    $('#include-eval').addEventListener('change', updateEvaluationVisibility);
}

window.addEventListener('DOMContentLoaded', () => {
    applyTheme(getStoredTheme());
    restoreConfig();
    renderDatasetSummary(state.trainDatasetSummary, 'train');
    renderDatasetSummary(state.testDatasetSummary, 'test');
    renderDatasetSummary(state.valDatasetSummary, 'val');
    updateGenericVisibility();
    updateEvaluationVisibility();
    bindEvents();
    checkTrainingStatus();
    checkEvaluationStatus();
});
