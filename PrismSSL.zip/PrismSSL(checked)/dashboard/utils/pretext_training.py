from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any
import traceback


class PretextTrainingError(Exception):
    """Raised when background pretext training cannot be launched."""


def _write_config_snapshot(config: Dict[str, Any]) -> Path:
    trainer = config.get("trainer", {}) or {}
    ctor = trainer.get("trainer_ctor", {}) or {}
    save_dir = Path(ctor.get("save_dir") or "./checkpoints").expanduser().resolve()
    save_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    snapshot_path = save_dir / f"pretext_config_{timestamp}.json"
    snapshot_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return snapshot_path


def _execute_real_training(config: Dict[str, Any]) -> None:
    """Execute training using PrismSSL Trainer with provided configuration."""
    # Lazy imports to avoid hard dependency when not available
    try:
        from PrismSSL.audio.Trainer import Trainer  # type: ignore
    except Exception as exc:  # pragma: no cover - runtime guard
        raise PretextTrainingError(f"PrismSSL Trainer unavailable: {exc}") from exc

    try:
        from .dataset_loader import instantiate_datasets
    except Exception as exc:  # pragma: no cover - should always be available
        raise PretextTrainingError(f"Dataset utilities unavailable: {exc}") from exc

    trainer_config = config.get("trainer", {}) or {}
    ctor = trainer_config.get("trainer_ctor", {}) or {}

    # Instantiate Trainer with mapped ctor fields
    trainer = Trainer(
        method=ctor.get("method", "ssl_method"),
        backbone=None,
        variant=ctor.get("variant", "base"),
        save_dir=ctor.get("save_dir", "."),
        checkpoint_interval=int(ctor.get("checkpoint_interval", 10) or 10),
        reload_checkpoint=bool(ctor.get("reload_checkpoint", False)),
        verbose=bool(ctor.get("verbose", True)),
        mixed_precision_training=bool(ctor.get("mixed_precision_training", True)),
        # W&B
        wandb_project=ctor.get("wandb_project"),
        wandb_entity=ctor.get("wandb_entity"),
        wandb_mode=ctor.get("wandb_mode", "online"),
        wandb_run_name=ctor.get("wandb_run_name"),
        wandb_config=ctor.get("wandb_config"),
        wandb_notes=ctor.get("wandb_notes"),
        wandb_tags=ctor.get("wandb_tags"),
        use_data_parallel=bool(ctor.get("use_data_parallel", False)),
        num_workers=ctor.get("num_workers"),
    )

    # Instantiate datasets
    dataset_cfg = config.get("dataset", {}) or {}

    train_dataset = None
    val_dataset = None

    train_meta = dataset_cfg.get("train")
    if train_meta and train_meta.get("code") and train_meta.get("class_name"):
        try:
            ds_map, _ = instantiate_datasets(
                train_meta["code"],
                train_meta["class_name"],
                train_meta.get("kwargs", {}) or {},
                None,
                None,
            )
            train_dataset = ds_map.get("train")
        except Exception as exc:
            raise PretextTrainingError(f"Failed to instantiate training dataset: {exc}") from exc

    val_meta = dataset_cfg.get("val")
    if val_meta and val_meta.get("code") and val_meta.get("class_name"):
        try:
            # Reuse train kwargs slot to instantiate a standalone dataset instance
            ds_map, _ = instantiate_datasets(
                val_meta["code"],
                val_meta["class_name"],
                val_meta.get("kwargs", {}) or {},
                None,
                None,
            )
            val_dataset = ds_map.get("train")  # created under 'train' key by helper
        except Exception as exc:
            # Proceed without validation if it fails to instantiate
            print(f"[PretextTraining] Warning: failed to instantiate validation dataset: {exc}", flush=True)

    if train_dataset is None:
        raise PretextTrainingError("Training dataset is required to start training.")

    # Train args mapping
    train_args = config.get("train", {}) or {}
    trainer.train(
        train_dataset=train_dataset,
        val_dataset=val_dataset,
        batch_size=int(train_args.get("batch_size", 16) or 16),
        start_epoch=int(train_args.get("start_epoch", 0) or 0),
        epochs=int(train_args.get("epochs", 100) or 100),
        start_iteration=int(train_args.get("start_iteration", 0) or 0),
        learning_rate=float(train_args.get("learning_rate", 1e-4) or 1e-4),
        weight_decay=float(train_args.get("weight_decay", 1e-2) or 1e-2),
        optimizer=str(train_args.get("optimizer", "adamw") or "adamw"),
        use_hpo=bool(train_args.get("use_hpo", False)),
        n_trials=int(train_args.get("n_trials", 20) or 20),
        tuning_epochs=int(train_args.get("tuning_epochs", 5) or 5),
        use_embedding_logger=bool(train_args.get("use_embedding_logger", False)),
        logger_loader=None,
        **(train_args.get("extra_kwargs", {}) or {}),
    )
    print("[PretextTraining] Training completed successfully!", flush=True)


def run_pretext_training(config: Dict[str, Any], error_queue) -> None:
    """Entry point executed in a background process.

    The function stores the provided configuration snapshot to disk. If the
    environment variable ``PRISMSSL_TRAIN_COMMAND`` is defined it will be used
    to launch an external training command. Otherwise a short simulated
    training loop runs so the behaviour is observable out-of-the-box.
    """

    try:
        snapshot_path = _write_config_snapshot(config)
        print(
            f"[PretextTraining] Configuration snapshot written to {snapshot_path}",
            flush=True,
        )
    except Exception as exc:  # pragma: no cover - best-effort logging only
        raise PretextTrainingError(f"Unable to persist configuration: {exc}") from exc

    command = os.environ.get("PRISMSSL_TRAIN_COMMAND")
    if not command:
        try:
            _execute_real_training(config)
            return
        except PretextTrainingError as exc:
            print(f"[PretextTraining]{exc}", flush=True)
            return
        except Exception as exc:
            # error_queue.put(traceback.format_exc())
            error_queue.put(exc)
            return

    expanded_command = command.format(config=str(snapshot_path))
    print(f"[PretextTraining] Launching command: {expanded_command}", flush=True)

    # Import here to avoid unnecessary overhead for the simulation path.
    import subprocess

    try:
        completed = subprocess.run(expanded_command, shell=True, check=True)
        print(
            f"[PretextTraining] External command finished with return code {completed.returncode}",
            flush=True,
        )
    except subprocess.CalledProcessError as exc:  # pragma: no cover - runtime guard
        raise PretextTrainingError(
            f"Training command failed with exit code {exc.returncode}"
        ) from exc
