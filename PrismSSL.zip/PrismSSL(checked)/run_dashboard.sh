#!/bin/bash

# Determine which Python to use
if command -v python >/dev/null 2>&1; then
  PYTHON=python
elif command -v python3 >/dev/null 2>&1; then
  PYTHON=python3
else
  echo "❌ Error: Python not found (no 'python' or 'python3' on PATH)" >&2
  exit 127
fi

# Optional: activate virtual environment
# source .venv/bin/activate

# Navigate to the directory containing your app
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# Run Flask app
echo "🚀 Launching PrismSSL Dashboard on http://127.0.0.1:5123"
export FLASK_APP=./dashboard/app.py
export FLASK_ENV=development

# Use whichever Python was found
exec "$PYTHON" -m flask run -h 127.0.0.1 -p 5123
